### Para rodar:
- Instalar Maven
- Abrir diretório da aplicação no cmd e então:
  ``` 
  mvn clean install 
  mvn jetty:run
  ```
